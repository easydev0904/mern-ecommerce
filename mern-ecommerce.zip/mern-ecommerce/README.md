# MERN E-commerce Project

Setup and run instructions here.